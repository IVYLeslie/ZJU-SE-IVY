//
//  HW2_demoApp.swift
//  HW2_demo
//
//  Created by 朱雨珂 on 2022/4/27.
//

import SwiftUI

@main
struct HW2_demoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
